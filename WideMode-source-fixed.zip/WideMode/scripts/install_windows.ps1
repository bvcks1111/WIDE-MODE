# Installs WIDE MODE.vst3 into the system VST3 folder. Run from an ELEVATED PowerShell.
#   .\scripts\install_windows.ps1 -Source "build\WideMode_artefacts\Release\VST3\WIDE MODE.vst3"
param(
    [string]$Source = "build\WideMode_artefacts\Release\VST3\WIDE MODE.vst3"
)
$ErrorActionPreference = "Stop"
$dest = Join-Path $env:CommonProgramFiles "VST3"
if (-not (Test-Path $Source)) { throw "Plugin not found: $Source" }
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Recurse -Force $Source $dest
Write-Host "Installed to $dest. Rescan plugins in your DAW."
