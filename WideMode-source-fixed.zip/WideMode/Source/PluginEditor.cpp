#include "PluginEditor.h"
#include "ParamIDs.h"

using namespace ui;

namespace
{
    constexpr int kWidth = 940, kHeight = 560;
}

WideModeAudioProcessorEditor::WideModeAudioProcessorEditor (WideModeAudioProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&laf);

    // --- knob behaviour
    widthKnob.setArcOrigin (100.0);
    widthKnob.subtitleFn = [] (double v) -> juce::String
    {
        if (v < 0.5)   return "MONO";
        if (v < 99.5)  return "NARROWER";
        if (v < 100.5) return "ORIGINAL";
        if (v < 150.0) return "WIDER";
        return "ULTRA WIDE";
    };
    midKnob.setArcOrigin (0.0);
    sideKnob.setArcOrigin (0.0);
    outputKnob.setArcOrigin (0.0);

    for (auto* c : std::initializer_list<juce::Component*> { &widthKnob, &stereoizeKnob, &midKnob, &sideKnob,
                                                             &bassFreqKnob, &mixKnob, &outputKnob,
                                                             &bassToggle, &monoToggle, &inMeter, &outMeter, &corrMeter,
                                                             &presetBox, &prevButton, &nextButton, &saveButton, &folderButton })
        addAndMakeVisible (c);

    // --- parameter attachments (created after the controls exist)
    widthA     = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::width,     widthKnob);
    stereoizeA = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::stereoize, stereoizeKnob);
    midA       = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::midGain,   midKnob);
    sideA      = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::sideGain,  sideKnob);
    bassFreqA  = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::bassFreq,  bassFreqKnob);
    mixA       = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::mix,       mixKnob);
    outputA    = std::make_unique<SliderAttachment> (proc.apvts, ParamIDs::output,    outputKnob);
    bassA      = std::make_unique<ButtonAttachment> (proc.apvts, ParamIDs::bassMono,  bassToggle);
    monoA      = std::make_unique<ButtonAttachment> (proc.apvts, ParamIDs::monoCheck, monoToggle);

    // --- presets
    presetBox.setJustificationType (juce::Justification::centred);
    presetBox.setTextWhenNothingSelected ("Custom");
    presetBox.onChange = [this]
    {
        const int id = presetBox.getSelectedId();
        if (id > 0)
        {
            proc.presets.load (id - 1);
            lastShownPreset = id - 1;
        }
    };
    prevButton.onClick   = [this] { stepPreset (-1); };
    nextButton.onClick   = [this] { stepPreset (+1); };
    saveButton.onClick   = [this] { promptSavePreset(); };
    folderButton.onClick = []
    {
        auto dir = PresetManager::getUserFolder();
        dir.createDirectory();
        dir.revealToUser();
    };
    rebuildPresetMenu();
    syncPresetSelection();

    setResizable (false, false);
    setSize (kWidth, kHeight);
    startTimerHz (60);
}

WideModeAudioProcessorEditor::~WideModeAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

//==============================================================================
void WideModeAudioProcessorEditor::rebuildPresetMenu()
{
    presetBox.clear (juce::dontSendNotification);
    const auto& list = proc.presets.getPresets();
    const int nFactory = proc.presets.getNumFactory();

    presetBox.addSectionHeading ("FACTORY");
    for (int i = 0; i < nFactory; ++i)
        presetBox.addItem (list[(size_t) i].name, i + 1);

    if ((int) list.size() > nFactory)
    {
        presetBox.addSeparator();
        presetBox.addSectionHeading ("USER");
        for (int i = nFactory; i < (int) list.size(); ++i)
            presetBox.addItem (list[(size_t) i].name, i + 1);
    }
    lastShownPreset = -2;
}

void WideModeAudioProcessorEditor::syncPresetSelection()
{
    const int idx = proc.presets.findMatchingPreset();      // -1 => "Custom"
    if (idx == lastShownPreset)
        return;
    lastShownPreset = idx;
    presetBox.setSelectedId (idx >= 0 ? idx + 1 : 0, juce::dontSendNotification);
}

void WideModeAudioProcessorEditor::stepPreset (int direction)
{
    const int n = (int) proc.presets.getPresets().size();
    if (n == 0)
        return;
    int cur = proc.presets.findMatchingPreset();
    cur = cur < 0 ? (direction > 0 ? -1 : 0) : cur;
    const int next = (cur + direction + n) % n;
    proc.presets.load (next);
    lastShownPreset = next;
    presetBox.setSelectedId (next + 1, juce::dontSendNotification);
}

void WideModeAudioProcessorEditor::promptSavePreset()
{
    auto* w = new juce::AlertWindow ("Save preset", "Give your preset a name:",
                                     juce::MessageBoxIconType::NoIcon, this);
    w->addTextEditor ("name", "My Preset");
    w->addButton ("Save",   1, juce::KeyPress (juce::KeyPress::returnKey));
    w->addButton ("Cancel", 0, juce::KeyPress (juce::KeyPress::escapeKey));

    juce::Component::SafePointer<WideModeAudioProcessorEditor> safe (this);
    w->enterModalState (true,
                        juce::ModalCallbackFunction::create ([safe, w] (int result)
                        {
                            if (result != 1 || safe == nullptr)
                                return;
                            if (safe->proc.presets.saveUserPreset (w->getTextEditorContents ("name")))
                            {
                                safe->rebuildPresetMenu();
                                safe->syncPresetSelection();
                            }
                        }),
                        true);
}

void WideModeAudioProcessorEditor::timerCallback()
{
    // exchange(0): the DSP accumulates peaks between UI frames, so none are missed
    inMeter.push  (proc.dsp.inPeakL.exchange (0.0f),  proc.dsp.inPeakR.exchange (0.0f));
    outMeter.push (proc.dsp.outPeakL.exchange (0.0f), proc.dsp.outPeakR.exchange (0.0f));
    corrMeter.setValues (proc.dsp.outCorr.load(), proc.dsp.inCorr.load());

    if (++presetTick >= 8)
    {
        presetTick = 0;
        syncPresetSelection();
    }
}

//==============================================================================
void WideModeAudioProcessorEditor::paint (juce::Graphics& g)
{
    using namespace ui::col;
    const auto b = getLocalBounds().toFloat();

    g.setGradientFill (juce::ColourGradient (bgTop, 0.0f, 0.0f, bgBottom, 0.0f, b.getHeight(), false));
    g.fillAll();

    // soft light behind the main knob
    const float kx = b.getCentreX(), ky = 250.0f;
    g.setGradientFill (juce::ColourGradient (violet.withAlpha (0.10f), kx, ky,
                                             juce::Colours::transparentBlack, kx, ky + 240.0f, true));
    g.fillRect (b);
    g.setGradientFill (juce::ColourGradient (cyan.withAlpha (0.06f), kx - 40.0f, ky + 20.0f,
                                             juce::Colours::transparentBlack, kx - 40.0f, ky + 200.0f, true));
    g.fillRect (b);

    // header
    g.setColour (juce::Colour (0xff0a0c11));
    g.fillRect (0.0f, 0.0f, b.getWidth(), 72.0f);
    g.setColour (panelEdge);
    g.fillRect (0.0f, 71.0f, b.getWidth(), 1.0f);

    // logo
    {
        const auto f = makeFont (27.0f, true).withExtraKerningFactor (0.12f);
        g.setFont (f);
        g.setColour (text);
        const float w1 = textWidth (f, "WIDE");
        g.drawText ("WIDE", juce::Rectangle<float> (26.0f, 14.0f, w1 + 6.0f, 34.0f), juce::Justification::centredLeft, false);
        g.setGradientFill (juce::ColourGradient (cyan, 26.0f + w1 + 12.0f, 14.0f, violet, 26.0f + w1 + 110.0f, 48.0f, false));
        g.drawText ("MODE", juce::Rectangle<float> (26.0f + w1 + 12.0f, 14.0f, 120.0f, 34.0f), juce::Justification::centredLeft, false);
        g.setColour (dim);
        g.setFont (makeFont (10.0f, true).withExtraKerningFactor (0.3f));
        g.drawText ("STEREO IMAGE PROCESSOR", juce::Rectangle<float> (28.0f, 47.0f, 220.0f, 14.0f), juce::Justification::centredLeft, false);
    }

    // panels
    for (const auto& r : { leftPanel, rightPanel })
    {
        const auto rf = r.toFloat();
        g.setColour (panel.withAlpha (0.85f));
        g.fillRoundedRectangle (rf, 14.0f);
        g.setColour (panelEdge);
        g.drawRoundedRectangle (rf.reduced (0.5f), 14.0f, 1.0f);
    }

    const auto header = [&g] (const juce::String& s, int x, int y, int w)
    {
        g.setColour (dim);
        g.setFont (makeFont (10.5f, true).withExtraKerningFactor (0.3f));
        g.drawText (s, x, y, w, 16, juce::Justification::centred, false);
    };
    header ("M / S  BALANCE",  leftPanel.getX(),  leftPanel.getY() + 12,  leftPanel.getWidth());
    header ("ENHANCE",         leftPanel.getX(),  leftPanel.getY() + 184, leftPanel.getWidth());
    header ("LOW END",         rightPanel.getX(), rightPanel.getY() + 12, rightPanel.getWidth());
    header ("BLEND  /  LEVEL", rightPanel.getX(), rightPanel.getY() + 222, rightPanel.getWidth());

    g.setColour (panelEdge);
    g.fillRect (leftPanel.getX() + 20, leftPanel.getY() + 172, leftPanel.getWidth() - 40, 1);
    g.fillRect (rightPanel.getX() + 20, rightPanel.getY() + 210, rightPanel.getWidth() - 40, 1);

    g.setColour (dim.withAlpha (0.8f));
    g.setFont (makeFont (10.5f));
    g.drawFittedText ("Adds decorrelated side content derived from the mid. The mono sum stays identical.",
                      leftPanel.getX() + 22, leftPanel.getBottom() - 70, leftPanel.getWidth() - 44, 52,
                      juce::Justification::centredTop, 3);
    g.drawFittedText ("Only the side channel below the crossover is removed. Centered bass is untouched.",
                      rightPanel.getX() + 22, rightPanel.getBottom() - 70, rightPanel.getWidth() - 44, 52,
                      juce::Justification::centredTop, 3);
}

void WideModeAudioProcessorEditor::resized()
{
    // meters
    inMeter.setBounds (16, 88, 76, 456);
    outMeter.setBounds (848, 88, 76, 456);

    // panels
    leftPanel  = { 104, 88, 220, 456 };
    rightPanel = { 616, 88, 220, 456 };

    // left: M/S + stereoize
    midKnob.setBounds (leftPanel.getX() + 6,   leftPanel.getY() + 34, 104, 134);
    sideKnob.setBounds (leftPanel.getX() + 110, leftPanel.getY() + 34, 104, 134);
    stereoizeKnob.setBounds (leftPanel.getX() + (220 - 136) / 2, leftPanel.getY() + 206, 136, 170);

    // right: bass mono + mix/output
    bassToggle.setBounds (rightPanel.getX() + 22, rightPanel.getY() + 38, 176, 30);
    bassFreqKnob.setBounds (rightPanel.getX() + 58, rightPanel.getY() + 74, 104, 134);
    mixKnob.setBounds (rightPanel.getX() + 6,    rightPanel.getY() + 244, 104, 134);
    outputKnob.setBounds (rightPanel.getX() + 110, rightPanel.getY() + 244, 104, 134);

    // centre
    widthKnob.setBounds ((kWidth - 300) / 2, 92, 300, 300);
    corrMeter.setBounds ((kWidth - 260) / 2, 420, 260, 100);

    // header: preset bar + mono check
    const int y = 22, h = 28;
    int x = 262;
    prevButton.setBounds (x, y, 30, h);            x += 36;
    presetBox.setBounds (x, y, 210, h);            x += 216;
    nextButton.setBounds (x, y, 30, h);            x += 42;
    saveButton.setBounds (x, y, 62, h);            x += 68;
    folderButton.setBounds (x, y, 72, h);
    monoToggle.setBounds (kWidth - 26 - 150, 20, 150, 32);
}
