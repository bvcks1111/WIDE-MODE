#include "PresetManager.h"
#include "ParamIDs.h"
#include <algorithm>

namespace
{
    // Order of values: width, stereoize, bassMono(0/1), bassFreq, mid, side, mix, output
    const char* const kIds[PresetManager::kNumParams] =
    {
        ParamIDs::width, ParamIDs::stereoize, ParamIDs::bassMono, ParamIDs::bassFreq,
        ParamIDs::midGain, ParamIDs::sideGain, ParamIDs::mix, ParamIDs::output
    };

    struct FactoryPreset { const char* name; PresetManager::Values v; };

    const FactoryPreset kFactory[] =
    {
        { "Init (Bypass-Transparent)", { { 100.f,  0.f, 0.f, 120.f,  0.0f,  0.0f, 100.f,  0.0f } } },
        { "Subtle Widen",              { { 120.f, 10.f, 1.f, 100.f,  0.0f,  0.0f, 100.f, -0.5f } } },
        { "Mastering Gentle",          { { 112.f,  8.f, 1.f, 120.f,  0.0f,  0.5f, 100.f, -0.3f } } },
        { "Wide Pop",                  { { 135.f, 25.f, 1.f, 130.f,  0.0f,  1.0f, 100.f, -1.0f } } },
        { "Ultra Wide",                { { 180.f, 40.f, 1.f, 150.f, -0.5f,  1.5f, 100.f, -2.0f } } },
        { "Vocal Safe",                { { 110.f, 15.f, 1.f, 160.f,  1.0f, -1.0f, 100.f,  0.0f } } },
        { "Tight Low End",             { { 100.f,  0.f, 1.f, 220.f,  0.0f,  0.0f, 100.f,  0.0f } } },
        { "Stereoize Only",            { { 100.f, 60.f, 1.f, 120.f,  0.0f,  0.0f, 100.f, -0.5f } } },
        { "Narrow / Mono-ish",         { {  40.f,  0.f, 1.f, 120.f,  0.0f,  0.0f, 100.f,  0.0f } } },
    };
}

PresetManager::PresetManager (juce::AudioProcessorValueTreeState& s) : apvts (s)
{
    refresh();
}

juce::File PresetManager::getUserFolder()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("WideMode").getChildFile ("Presets");
}

void PresetManager::refresh()
{
    presets.clear();
    for (const auto& f : kFactory)
        presets.push_back ({ f.name, true, f.v });
    numFactory = (int) presets.size();

    std::vector<juce::File> files;
    for (const auto& f : getUserFolder().findChildFiles (juce::File::findFiles, false, "*.wmpreset"))
        files.push_back (f);
    std::sort (files.begin(), files.end(), [] (const juce::File& a, const juce::File& b)
               { return a.getFileNameWithoutExtension().compareIgnoreCase (b.getFileNameWithoutExtension()) < 0; });

    for (const auto& file : files)
    {
        if (auto xml = juce::parseXML (file))
        {
            if (! xml->hasTagName ("WideModePreset"))
                continue;

            Preset p;
            p.isFactory = false;
            p.name = xml->getStringAttribute ("name", file.getFileNameWithoutExtension());
            for (int i = 0; i < kNumParams; ++i)
                p.values[(size_t) i] = (float) xml->getDoubleAttribute (kIds[i], kFactory[0].v[(size_t) i]);
            presets.push_back (std::move (p));
        }
    }
}

bool PresetManager::load (int index)
{
    if (index < 0 || index >= (int) presets.size())
        return false;

    const auto& p = presets[(size_t) index];
    for (int i = 0; i < kNumParams; ++i)
    {
        if (auto* param = apvts.getParameter (kIds[i]))
        {
            param->beginChangeGesture();
            param->setValueNotifyingHost (param->convertTo0to1 (p.values[(size_t) i]));
            param->endChangeGesture();
        }
    }
    return true;
}

PresetManager::Values PresetManager::readCurrent() const
{
    Values v {};
    for (int i = 0; i < kNumParams; ++i)
        if (auto* raw = apvts.getRawParameterValue (kIds[i]))
            v[(size_t) i] = raw->load();
    return v;
}

bool PresetManager::saveUserPreset (const juce::String& rawName)
{
    auto name = rawName.trim();
    if (name.isEmpty())
        return false;

    for (int i = 0; i < numFactory; ++i)               // never shadow a factory preset
        if (presets[(size_t) i].name.equalsIgnoreCase (name))
            name << " (User)";

    auto dir = getUserFolder();
    if (! dir.createDirectory().wasOk())
        return false;

    juce::XmlElement xml ("WideModePreset");
    xml.setAttribute ("name", name);
    xml.setAttribute ("version", 1);
    const auto cur = readCurrent();
    for (int i = 0; i < kNumParams; ++i)
        xml.setAttribute (kIds[i], (double) cur[(size_t) i]);

    const bool ok = xml.writeTo (dir.getChildFile (juce::File::createLegalFileName (name) + ".wmpreset"));
    refresh();
    return ok;
}

int PresetManager::findMatchingPreset() const
{
    const auto cur = readCurrent();
    std::array<float, kNumParams> tol {};
    for (int i = 0; i < kNumParams; ++i)
        tol[(size_t) i] = (apvts.getParameter (kIds[i]) != nullptr
                               ? apvts.getParameter (kIds[i])->getNormalisableRange().interval : 0.1f) * 0.5f + 1.0e-3f;

    for (int idx = 0; idx < (int) presets.size(); ++idx)
    {
        bool match = true;
        for (int i = 0; i < kNumParams && match; ++i)
            match = std::abs (cur[(size_t) i] - presets[(size_t) idx].values[(size_t) i]) <= tol[(size_t) i];
        if (match)
            return idx;
    }
    return -1;
}
