#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "ParamIDs.h"

using namespace juce;

AudioProcessorValueTreeState::ParameterLayout WideModeAudioProcessor::createParameterLayout()
{
    using Attr = AudioParameterFloatAttributes;
    AudioProcessorValueTreeState::ParameterLayout layout;

    const auto pctText = [] (float v, int) { return String (roundToInt (v)) + "%"; };
    const auto dbText  = [] (float v, int) { return String (std::abs (v) < 0.05f ? 0.0f : v, 1) + " dB"; };
    const auto hzText  = [] (float v, int) { return String (roundToInt (v)) + " Hz"; };
    const auto fromText = [] (const String& t) { return t.retainCharacters ("0123456789.-").getFloatValue(); };

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::width, 1 }, "Width",
        NormalisableRange<float> (0.0f, 200.0f, 0.1f), 100.0f,
        Attr().withStringFromValueFunction (pctText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::stereoize, 1 }, "Stereoize",
        NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f,
        Attr().withStringFromValueFunction (pctText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterBool> (
        ParameterID { ParamIDs::bassMono, 1 }, "Bass Mono", false));

    NormalisableRange<float> freqRange (60.0f, 300.0f, 1.0f);
    freqRange.setSkewForCentre (130.0f);
    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::bassFreq, 1 }, "Bass Mono Frequency", freqRange, 120.0f,
        Attr().withStringFromValueFunction (hzText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::midGain, 1 }, "Mid Gain",
        NormalisableRange<float> (-24.0f, 12.0f, 0.1f), 0.0f,
        Attr().withStringFromValueFunction (dbText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::sideGain, 1 }, "Side Gain",
        NormalisableRange<float> (-24.0f, 12.0f, 0.1f), 0.0f,
        Attr().withStringFromValueFunction (dbText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::mix, 1 }, "Mix",
        NormalisableRange<float> (0.0f, 100.0f, 0.1f), 100.0f,
        Attr().withStringFromValueFunction (pctText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::output, 1 }, "Output",
        NormalisableRange<float> (-18.0f, 18.0f, 0.1f), 0.0f,
        Attr().withStringFromValueFunction (dbText).withValueFromStringFunction (fromText)));

    layout.add (std::make_unique<AudioParameterBool> (
        ParameterID { ParamIDs::monoCheck, 1 }, "Mono Check", false));

    return layout;
}

WideModeAudioProcessor::WideModeAudioProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  AudioChannelSet::stereo(), true)
                          .withOutput ("Output", AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "WIDEMODE_STATE", createParameterLayout()),
      presets (apvts)
{
    pWidth     = apvts.getRawParameterValue (ParamIDs::width);
    pStereoize = apvts.getRawParameterValue (ParamIDs::stereoize);
    pBassMono  = apvts.getRawParameterValue (ParamIDs::bassMono);
    pBassFreq  = apvts.getRawParameterValue (ParamIDs::bassFreq);
    pMid       = apvts.getRawParameterValue (ParamIDs::midGain);
    pSide      = apvts.getRawParameterValue (ParamIDs::sideGain);
    pMix       = apvts.getRawParameterValue (ParamIDs::mix);
    pOutput    = apvts.getRawParameterValue (ParamIDs::output);
    pMonoCheck = apvts.getRawParameterValue (ParamIDs::monoCheck);
}

widemode::Params WideModeAudioProcessor::readParams() const
{
    widemode::Params p;
    p.widthPct     = pWidth->load();
    p.stereoizePct = pStereoize->load();
    p.bassMonoOn   = pBassMono->load() > 0.5f;
    p.bassFreqHz   = pBassFreq->load();
    p.midDb        = pMid->load();
    p.sideDb       = pSide->load();
    p.mixPct       = pMix->load();
    p.outputDb     = pOutput->load();
    p.monoCheck    = pMonoCheck->load() > 0.5f;
    return p;
}

void WideModeAudioProcessor::prepareToPlay (double sampleRate, int)
{
    dsp.prepare (sampleRate);
    dsp.setParams (readParams(), true);
}

bool WideModeAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet()  == AudioChannelSet::stereo()
        && layouts.getMainOutputChannelSet() == AudioChannelSet::stereo();
}

void WideModeAudioProcessor::processBlock (AudioBuffer<float>& buffer, MidiBuffer&)
{
    ScopedNoDenormals noDenormals;

    if (buffer.getNumChannels() < 2)
        return;

    dsp.setParams (readParams());
    dsp.process (buffer.getWritePointer (0), buffer.getWritePointer (1), buffer.getNumSamples());
}

AudioProcessorEditor* WideModeAudioProcessor::createEditor()
{
    return new WideModeAudioProcessorEditor (*this);
}

void WideModeAudioProcessor::getStateInformation (MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void WideModeAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (ValueTree::fromXml (*xml));
}

// Required entry point for every JUCE plugin format.
AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new WideModeAudioProcessor();
}
