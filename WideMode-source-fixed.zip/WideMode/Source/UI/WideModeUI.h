// WIDE MODE - custom UI components (dark, mastering-grade look).
#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <cmath>
#include <functional>

namespace ui
{
namespace col
{
    inline const juce::Colour bgTop     { 0xff11141c };
    inline const juce::Colour bgBottom  { 0xff07080c };
    inline const juce::Colour panel     { 0xff131722 };
    inline const juce::Colour panelEdge { 0xff222a3a };
    inline const juce::Colour text      { 0xffeaeef6 };
    inline const juce::Colour dim       { 0xff7b869b };
    inline const juce::Colour cyan      { 0xff3be0ff };
    inline const juce::Colour violet    { 0xff8f6bff };
    inline const juce::Colour amber     { 0xffffc247 };
    inline const juce::Colour red       { 0xffff4d5e };
    inline const juce::Colour segOff    { 0xff151a25 };
}

inline juce::Font makeFont (float height, bool bold = false)
{
   #if JUCE_MAJOR_VERSION >= 8
    return juce::Font (juce::FontOptions (height, bold ? juce::Font::bold : juce::Font::plain));
   #else
    return juce::Font (height, bold ? juce::Font::bold : juce::Font::plain);
   #endif
}

inline float textWidth (const juce::Font& f, const juce::String& s)
{
    juce::GlyphArrangement ga;
    ga.addLineOfText (f, s, 0.0f, 0.0f);
    return ga.getBoundingBox (0, -1, true).getWidth();
}

//==============================================================================
/** Rotary knob with animated value arc, hover glow and built-in value/caption text. */
class KnobSlider : public juce::Slider, private juce::Timer
{
public:
    explicit KnobSlider (const juce::String& captionText, bool big = false)
        : juce::Slider (juce::Slider::RotaryVerticalDrag, juce::Slider::NoTextBox),
          caption (captionText), isBig (big)
    {
        setRotaryParameters (juce::MathConstants<float>::pi * 1.2f,
                             juce::MathConstants<float>::pi * 2.8f, true);
        setMouseDragSensitivity (big ? 260 : 180);
        setVelocityBasedMode (false);
        startTimerHz (60);
    }

    /** Draw the value arc starting at this value instead of at the minimum (bipolar knobs). */
    void setArcOrigin (double value) { arcOrigin = value; hasOrigin = true; }

    std::function<juce::String (double)> subtitleFn;   // big knob: text under the value

    void paint (juce::Graphics& g) override
    {
        using namespace col;
        const auto b = getLocalBounds().toFloat();
        const float footerH = isBig ? 0.0f : 36.0f;
        const auto area = b.withTrimmedBottom (footerH).reduced (isBig ? 16.0f : 5.0f);
        const float d = juce::jmin (area.getWidth(), area.getHeight());
        const auto kb = juce::Rectangle<float> (d, d).withCentre (area.getCentre());
        const auto c = kb.getCentre();
        const float R = d * 0.5f;

        const float thick = isBig ? 9.0f : 4.5f;
        const float arcR = R - thick * 0.5f;
        const float bodyR = arcR - thick * 0.5f - (isBig ? 15.0f : 6.0f);
        const float a0 = getRotaryParameters().startAngleRadians;
        const float a1 = getRotaryParameters().endAngleRadians;
        const float aVal = a0 + prop * (a1 - a0);

        // ambient glow
        {
            juce::ColourGradient glow (cyan.withAlpha (0.05f + 0.10f * hover), c.x, c.y,
                                       cyan.withAlpha (0.0f), c.x + R * 1.35f, c.y, true);
            g.setGradientFill (glow);
            g.fillEllipse (c.x - R * 1.35f, c.y - R * 1.35f, R * 2.7f, R * 2.7f);
        }

        // track
        juce::Path track;
        track.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0, a1, true);
        g.setColour (juce::Colour (0xff1b2130));
        g.strokePath (track, juce::PathStrokeType (thick, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // value arc
        float aFrom = a0;
        if (hasOrigin)
            aFrom = a0 + (float) valueToProportionOfLength (arcOrigin) * (a1 - a0);
        const float lo = juce::jmin (aFrom, aVal), hi = juce::jmax (aFrom, aVal);
        if (hi - lo > 0.01f)
        {
            juce::Path vp;
            vp.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, lo, hi, true);
            g.setColour (cyan.withAlpha (0.10f + 0.20f * hover));
            g.strokePath (vp, juce::PathStrokeType (thick + (isBig ? 10.0f : 6.0f),
                                                    juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setGradientFill (juce::ColourGradient (cyan, kb.getX(), kb.getBottom(),
                                                     violet, kb.getRight(), kb.getY(), false));
            g.strokePath (vp, juce::PathStrokeType (thick, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // tick marks (big knob only)
        if (isBig)
        {
            const int n = 40;
            for (int i = 0; i <= n; ++i)
            {
                const float a = a0 + (float) i / (float) n * (a1 - a0);
                const bool major = (i % 10) == 0;
                const float r0 = R + 3.0f, r1 = R + (major ? 11.0f : 7.0f);
                g.setColour (dim.withAlpha (major ? 0.8f : 0.4f));
                g.drawLine (c.x + std::sin (a) * r0, c.y - std::cos (a) * r0,
                            c.x + std::sin (a) * r1, c.y - std::cos (a) * r1, major ? 1.6f : 1.0f);
            }
        }

        // body
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff2c3445), c.x, c.y - bodyR,
                                                 juce::Colour (0xff0d1016), c.x, c.y + bodyR, false));
        g.fillEllipse (c.x - bodyR, c.y - bodyR, bodyR * 2.0f, bodyR * 2.0f);
        g.setColour (juce::Colour (0xff3b455a).withAlpha (0.85f));
        g.drawEllipse (c.x - bodyR, c.y - bodyR, bodyR * 2.0f, bodyR * 2.0f, 1.2f);

        const float faceR = bodyR * 0.84f;
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff161a24), c.x, c.y - faceR,
                                                 juce::Colour (0xff1f2531), c.x, c.y + faceR, false));
        g.fillEllipse (c.x - faceR, c.y - faceR, faceR * 2.0f, faceR * 2.0f);

        // pointer
        {
            const float p0 = bodyR * (isBig ? 0.80f : 0.38f);
            const float p1 = bodyR * (isBig ? 0.96f : 0.90f);
            juce::Path ptr;
            ptr.startNewSubPath (c.x + std::sin (aVal) * p0, c.y - std::cos (aVal) * p0);
            ptr.lineTo (c.x + std::sin (aVal) * p1, c.y - std::cos (aVal) * p1);
            g.setColour (cyan.withAlpha (0.25f + 0.2f * hover));
            g.strokePath (ptr, juce::PathStrokeType (isBig ? 9.0f : 6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour (text);
            g.strokePath (ptr, juce::PathStrokeType (isBig ? 3.5f : 2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        const auto valueText = getTextFromValue (getValue());

        if (isBig)
        {
            g.setColour (dim);
            g.setFont (makeFont (13.0f, true).withExtraKerningFactor (0.3f));
            g.drawText (caption, juce::Rectangle<float> (c.x - 80.0f, c.y - faceR * 0.66f, 160.0f, 18.0f),
                        juce::Justification::centred, false);

            g.setColour (text);
            g.setFont (makeFont (50.0f, true));
            g.drawText (valueText, juce::Rectangle<float> (c.x - 90.0f, c.y - 32.0f, 180.0f, 64.0f),
                        juce::Justification::centred, false);

            if (subtitleFn)
            {
                g.setColour (cyan);
                g.setFont (makeFont (12.0f, true).withExtraKerningFactor (0.25f));
                g.drawText (subtitleFn (getValue()),
                            juce::Rectangle<float> (c.x - 80.0f, c.y + faceR * 0.42f, 160.0f, 18.0f),
                            juce::Justification::centred, false);
            }
        }
        else
        {
            g.setColour (text);
            g.setFont (makeFont (13.0f, true));
            g.drawText (valueText, juce::Rectangle<float> (b.getX(), kb.getBottom() + 3.0f, b.getWidth(), 17.0f),
                        juce::Justification::centred, false);
            g.setColour (dim);
            g.setFont (makeFont (10.5f, true).withExtraKerningFactor (0.2f));
            g.drawText (caption, juce::Rectangle<float> (b.getX(), kb.getBottom() + 19.0f, b.getWidth(), 14.0f),
                        juce::Justification::centred, false);
        }
    }

    void valueChanged() override { repaint(); }

private:
    void timerCallback() override
    {
        const float tgtProp = (float) valueToProportionOfLength (getValue());
        const float tgtHover = isMouseOverOrDragging (true) ? 1.0f : 0.0f;
        const float oldP = prop, oldH = hover;

        prop  += (tgtProp - prop) * 0.30f;
        hover += (tgtHover - hover) * 0.20f;
        if (std::abs (prop - tgtProp) < 0.0005f)  prop = tgtProp;
        if (std::abs (hover - tgtHover) < 0.005f) hover = tgtHover;

        if (prop != oldP || hover != oldH)
            repaint();
    }

    juce::String caption;
    bool isBig = false;
    bool hasOrigin = false;
    double arcOrigin = 0.0;
    float prop = 0.0f, hover = 0.0f;
};

//==============================================================================
/** Segmented stereo peak meter with peak-hold and clickable max-peak readout. */
class StereoMeter : public juce::Component
{
public:
    explicit StereoMeter (const juce::String& titleText) : title (titleText) {}

    void push (float linL, float linR)
    {
        update (0, linL);
        update (1, linR);
        repaint();
    }

    void mouseDown (const juce::MouseEvent&) override { maxPeakDb = kMinDb - 1.0f; repaint(); }

    void paint (juce::Graphics& g) override
    {
        using namespace col;
        auto b = getLocalBounds().toFloat();

        g.setColour (dim);
        g.setFont (makeFont (11.0f, true).withExtraKerningFactor (0.2f));
        g.drawText (title, b.removeFromTop (22.0f), juce::Justification::centred, false);

        auto foot = b.removeFromBottom (26.0f);
        const bool clip = maxPeakDb > 0.0f;
        g.setColour (clip ? red : text);
        g.setFont (makeFont (12.0f, true));
        g.drawText (maxPeakDb <= kMinDb ? juce::String ("-inf") : juce::String (maxPeakDb, 1),
                    foot, juce::Justification::centred, false);

        const auto bars = b.reduced (0.0f, 4.0f);
        const float barW = 15.0f, midW = 28.0f;
        const float total = barW * 2.0f + midW;
        const float x0 = bars.getCentreX() - total * 0.5f;
        const float top = bars.getY(), bottom = bars.getBottom(), h = bottom - top;

        const float segH = 3.0f, gap = 1.0f, pitch = segH + gap;
        const int n = (int) (h / pitch);
        const float range = kMaxDb - kMinDb;

        for (int ch = 0; ch < 2; ++ch)
        {
            const float x = ch == 0 ? x0 : x0 + barW + midW;
            for (int i = 0; i < n; ++i)
            {
                const float segDb = kMinDb + ((float) i + 0.5f) / (float) n * range;
                const bool lit = level[ch] >= segDb;
                juce::Colour c = segDb > -0.5f ? red : (segDb > -9.0f ? amber : cyan);
                if (! lit) c = segOff;
                g.setColour (c);
                g.fillRect (x, bottom - (float) (i + 1) * pitch + gap, barW, segH);
            }
            const float hy = bottom - juce::jlimit (0.0f, 1.0f, (hold[ch] - kMinDb) / range) * (float) n * pitch;
            if (hold[ch] > kMinDb)
            {
                g.setColour (text.withAlpha (0.9f));
                g.fillRect (x, hy, barW, 2.0f);
            }
        }

        // scale
        g.setFont (makeFont (9.0f, true));
        for (float db : { 0.0f, -6.0f, -12.0f, -24.0f, -36.0f, -48.0f })
        {
            const float y = bottom - (db - kMinDb) / range * (float) n * pitch;
            g.setColour (dim.withAlpha (0.55f));
            g.drawText (juce::String ((int) db), juce::Rectangle<float> (x0 + barW, y - 6.0f, midW, 12.0f),
                        juce::Justification::centred, false);
        }
    }

private:
    static constexpr float kMinDb = -60.0f, kMaxDb = 6.0f;

    void update (int ch, float lin)
    {
        const float db = juce::Decibels::gainToDecibels (lin, -90.0f);
        if (db > level[ch]) level[ch] = db;
        else                level[ch] = juce::jmax (kMinDb - 1.0f, level[ch] - 0.7f);   // ~42 dB/s release

        if (db >= hold[ch]) { hold[ch] = db; holdFrames[ch] = 50; }
        else if (--holdFrames[ch] <= 0) hold[ch] = juce::jmax (level[ch], hold[ch] - 0.6f);

        maxPeakDb = juce::jmax (maxPeakDb, db);
    }

    juce::String title;
    float level[2] { kMinDb - 1.0f, kMinDb - 1.0f };
    float hold[2]  { kMinDb - 1.0f, kMinDb - 1.0f };
    int holdFrames[2] { 0, 0 };
    float maxPeakDb = kMinDb - 1.0f;
};

//==============================================================================
/** Horizontal phase-correlation meter (-1 .. +1) with an input marker. */
class CorrelationMeter : public juce::Component
{
public:
    void setValues (float outCorr, float inCorr)
    {
        dispOut += (outCorr - dispOut) * 0.25f;
        dispIn  += (inCorr  - dispIn)  * 0.25f;
        repaint();
    }

    void paint (juce::Graphics& g) override
    {
        using namespace col;
        const auto b = getLocalBounds().toFloat();

        g.setColour (dim);
        g.setFont (makeFont (11.0f, true).withExtraKerningFactor (0.2f));
        g.drawText ("STEREO CORRELATION", b.withHeight (18.0f), juce::Justification::centredLeft, false);

        const juce::Colour valueCol = dispOut < 0.0f ? red : (dispOut < 0.2f ? amber : cyan);
        g.setColour (valueCol);
        g.setFont (makeFont (13.0f, true));
        g.drawText ((dispOut >= 0.0f ? "+" : "") + juce::String (dispOut, 2),
                    b.withHeight (18.0f), juce::Justification::centredRight, false);

        const juce::Rectangle<float> bar (b.getX(), b.getY() + 26.0f, b.getWidth(), 12.0f);
        g.setColour (segOff);
        g.fillRoundedRectangle (bar, 6.0f);

        const float cx = bar.getCentreX();
        const float vx = cx + juce::jlimit (-1.0f, 1.0f, dispOut) * bar.getWidth() * 0.5f;
        if (std::abs (vx - cx) > 0.5f)
        {
            juce::Graphics::ScopedSaveState ss (g);
            juce::Path clipPath;
            clipPath.addRoundedRectangle (bar, 6.0f);
            g.reduceClipRegion (clipPath);
            g.setGradientFill (juce::ColourGradient (valueCol.withAlpha (0.20f), cx, 0.0f, valueCol, vx, 0.0f, false));
            g.fillRect (juce::Rectangle<float> (juce::jmin (cx, vx), bar.getY(), std::abs (vx - cx), bar.getHeight()));
        }

        g.setColour (panelEdge);
        g.drawRoundedRectangle (bar, 6.0f, 1.0f);
        g.setColour (dim.withAlpha (0.7f));
        g.fillRect (cx - 0.5f, bar.getY() + 2.0f, 1.0f, bar.getHeight() - 4.0f);

        g.setColour (text);
        g.fillRoundedRectangle (vx - 1.5f, bar.getY() - 3.0f, 3.0f, bar.getHeight() + 6.0f, 1.5f);

        // input marker
        const float ix = cx + juce::jlimit (-1.0f, 1.0f, dispIn) * bar.getWidth() * 0.5f;
        juce::Path tri;
        tri.addTriangle (ix, bar.getBottom() + 3.0f, ix - 4.0f, bar.getBottom() + 9.0f, ix + 4.0f, bar.getBottom() + 9.0f);
        g.setColour (dim);
        g.fillPath (tri);

        g.setFont (makeFont (10.0f, true));
        const float ly = bar.getBottom() + 10.0f;
        g.drawText ("-1  PHASE", juce::Rectangle<float> (b.getX(), ly, 90.0f, 14.0f), juce::Justification::centredLeft, false);
        g.drawText ("0", juce::Rectangle<float> (cx - 20.0f, ly, 40.0f, 14.0f), juce::Justification::centred, false);
        g.drawText ("MONO  +1", juce::Rectangle<float> (b.getRight() - 90.0f, ly, 90.0f, 14.0f), juce::Justification::centredRight, false);

        juce::Path legend;
        legend.addTriangle (cx - 24.0f, ly + 32.0f, cx - 28.0f, ly + 38.0f, cx - 20.0f, ly + 38.0f);
        g.fillPath (legend);
        g.drawText ("= INPUT", juce::Rectangle<float> (cx - 16.0f, ly + 28.0f, 60.0f, 14.0f), juce::Justification::centredLeft, false);
    }

private:
    float dispOut = 1.0f, dispIn = 1.0f;
};

//==============================================================================
/** Pill toggle with LED and animated glow. */
class GlowToggle : public juce::ToggleButton, private juce::Timer
{
public:
    explicit GlowToggle (const juce::String& label, juce::Colour accentColour = col::cyan)
        : juce::ToggleButton (label), accent (accentColour)
    {
        setClickingTogglesState (true);
        setMouseCursor (juce::MouseCursor::PointingHandCursor);
        startTimerHz (60);
    }

    void paintButton (juce::Graphics& g, bool, bool) override
    {
        using namespace col;
        const auto b = getLocalBounds().toFloat().reduced (1.5f);

        g.setColour (juce::Colour (0xff10141c).interpolatedWith (accent.withAlpha (0.18f), glow));
        g.fillRoundedRectangle (b, 9.0f);
        g.setColour (panelEdge.interpolatedWith (accent, juce::jmax (glow, hover * 0.5f)));
        g.drawRoundedRectangle (b, 9.0f, 1.3f);

        const float ledX = b.getX() + 17.0f, ledY = b.getCentreY();
        if (glow > 0.01f)
        {
            g.setGradientFill (juce::ColourGradient (accent.withAlpha (0.55f * glow), ledX, ledY,
                                                     accent.withAlpha (0.0f), ledX + 13.0f, ledY, true));
            g.fillEllipse (ledX - 13.0f, ledY - 13.0f, 26.0f, 26.0f);
        }
        g.setColour (juce::Colour (0xff2a3142).interpolatedWith (accent, glow));
        g.fillEllipse (ledX - 4.5f, ledY - 4.5f, 9.0f, 9.0f);

        // col::text must be qualified: juce::Button has a private member called "text".
        g.setColour (dim.interpolatedWith (col::text, juce::jmax (glow, hover * 0.6f)));
        g.setFont (makeFont (12.0f, true).withExtraKerningFactor (0.15f));
        g.drawText (getButtonText(), b.withTrimmedLeft (32.0f), juce::Justification::centredLeft, false);
    }

private:
    void timerCallback() override
    {
        const float tg = getToggleState() ? 1.0f : 0.0f;
        const float th = isMouseOver (true) ? 1.0f : 0.0f;
        const float og = glow, oh = hover;
        glow  += (tg - glow) * 0.25f;
        hover += (th - hover) * 0.25f;
        if (std::abs (glow - tg) < 0.005f)  glow = tg;
        if (std::abs (hover - th) < 0.005f) hover = th;
        if (glow != og || hover != oh) repaint();
    }

    juce::Colour accent;
    float glow = 0.0f, hover = 0.0f;
};

//==============================================================================
class WideModeLookAndFeel : public juce::LookAndFeel_V4
{
public:
    WideModeLookAndFeel()
    {
        using namespace col;
        setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff0f131b));
        setColour (juce::ComboBox::textColourId, text);
        setColour (juce::ComboBox::outlineColourId, panelEdge);
        setColour (juce::ComboBox::arrowColourId, cyan);
        setColour (juce::ComboBox::focusedOutlineColourId, cyan);

        setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff12151e));
        setColour (juce::PopupMenu::textColourId, text);
        setColour (juce::PopupMenu::headerTextColourId, dim);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, cyan.withAlpha (0.22f));
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colours::white);

        setColour (juce::TextButton::buttonColourId, juce::Colour (0xff151a25));
        setColour (juce::TextButton::buttonOnColourId, cyan.withAlpha (0.3f));
        setColour (juce::TextButton::textColourOffId, text);
        setColour (juce::TextButton::textColourOnId, text);

        setColour (juce::AlertWindow::backgroundColourId, panel);
        setColour (juce::AlertWindow::textColourId, text);
        setColour (juce::AlertWindow::outlineColourId, panelEdge);
        setColour (juce::TextEditor::backgroundColourId, juce::Colour (0xff0d1016));
        setColour (juce::TextEditor::textColourId, text);
        setColour (juce::TextEditor::outlineColourId, panelEdge);
        setColour (juce::TextEditor::focusedOutlineColourId, cyan);
        setColour (juce::TextEditor::highlightColourId, cyan.withAlpha (0.35f));
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return makeFont (13.0f, true); }
    juce::Font getPopupMenuFont() override { return makeFont (13.0f); }
    juce::Font getTextButtonFont (juce::TextButton&, int) override
    {
        return makeFont (11.5f, true).withExtraKerningFactor (0.1f);
    }
};

} // namespace ui
