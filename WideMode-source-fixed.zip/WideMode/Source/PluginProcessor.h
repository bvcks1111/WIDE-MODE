#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "DSP/WideModeDSP.h"
#include "PresetManager.h"

class WideModeAudioProcessor : public juce::AudioProcessor
{
public:
    WideModeAudioProcessor();
    ~WideModeAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "WIDE MODE"; }
    bool acceptsMidi() const override  { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    PresetManager presets;
    widemode::WideModeDSP dsp;       // meters are read by the editor

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    widemode::Params readParams() const;

    std::atomic<float>* pWidth = nullptr;
    std::atomic<float>* pStereoize = nullptr;
    std::atomic<float>* pBassMono = nullptr;
    std::atomic<float>* pBassFreq = nullptr;
    std::atomic<float>* pMid = nullptr;
    std::atomic<float>* pSide = nullptr;
    std::atomic<float>* pMix = nullptr;
    std::atomic<float>* pOutput = nullptr;
    std::atomic<float>* pMonoCheck = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WideModeAudioProcessor)
};
