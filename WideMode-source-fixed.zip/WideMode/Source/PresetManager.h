#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <vector>

/// Factory + user presets.
/// User presets are small XML files (*.wmpreset) in  %APPDATA%\WideMode\Presets
/// so they can be backed up, shared, or deleted in Explorer.
/// Mono Check is deliberately NOT part of a preset (it is a monitoring switch).
class PresetManager
{
public:
    static constexpr int kNumParams = 8;
    using Values = std::array<float, kNumParams>;

    struct Preset
    {
        juce::String name;
        bool isFactory = true;
        Values values {};
    };

    explicit PresetManager (juce::AudioProcessorValueTreeState& state);

    void refresh();                                   // rescan user folder
    const std::vector<Preset>& getPresets() const noexcept { return presets; }
    int getNumFactory() const noexcept { return numFactory; }

    bool load (int index);                            // apply to parameters (host-notified)
    bool saveUserPreset (const juce::String& name);   // writes file + refreshes
    int  findMatchingPreset() const;                  // index of preset equal to current state, or -1

    static juce::File getUserFolder();

private:
    Values readCurrent() const;

    juce::AudioProcessorValueTreeState& apvts;
    std::vector<Preset> presets;
    int numFactory = 0;
};
