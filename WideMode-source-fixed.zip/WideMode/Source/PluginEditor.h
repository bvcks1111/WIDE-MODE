#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "UI/WideModeUI.h"

class WideModeAudioProcessorEditor : public juce::AudioProcessorEditor,
                                     private juce::Timer
{
public:
    explicit WideModeAudioProcessorEditor (WideModeAudioProcessor&);
    ~WideModeAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    void rebuildPresetMenu();
    void syncPresetSelection();
    void stepPreset (int direction);
    void promptSavePreset();

    WideModeAudioProcessor& proc;
    ui::WideModeLookAndFeel laf;                       // must outlive all child components

    ui::KnobSlider widthKnob      { "WIDTH", true };
    ui::KnobSlider stereoizeKnob  { "STEREOIZE" };
    ui::KnobSlider midKnob        { "MID" };
    ui::KnobSlider sideKnob       { "SIDE" };
    ui::KnobSlider bassFreqKnob   { "CROSSOVER" };
    ui::KnobSlider mixKnob        { "MIX" };
    ui::KnobSlider outputKnob     { "OUTPUT" };

    ui::GlowToggle bassToggle { "BASS MONO" };
    ui::GlowToggle monoToggle { "MONO CHECK", ui::col::amber };

    ui::StereoMeter inMeter  { "INPUT" };
    ui::StereoMeter outMeter { "OUTPUT" };
    ui::CorrelationMeter corrMeter;

    juce::ComboBox presetBox;
    juce::TextButton prevButton { "<" }, nextButton { ">" }, saveButton { "SAVE" }, folderButton { "FOLDER" };

    juce::Rectangle<int> leftPanel, rightPanel;
    int lastShownPreset = -2;
    int presetTick = 0;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SliderAttachment> widthA, stereoizeA, midA, sideA, bassFreqA, mixA, outputA;
    std::unique_ptr<ButtonAttachment> bassA, monoA;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WideModeAudioProcessorEditor)
};
