#pragma once

namespace ParamIDs
{
    inline constexpr const char* width      = "width";
    inline constexpr const char* stereoize  = "stereoize";
    inline constexpr const char* bassMono   = "bassMonoOn";
    inline constexpr const char* bassFreq   = "bassFreq";
    inline constexpr const char* midGain    = "midGain";
    inline constexpr const char* sideGain   = "sideGain";
    inline constexpr const char* mix        = "mix";
    inline constexpr const char* output     = "output";
    inline constexpr const char* monoCheck  = "monoCheck";
}
