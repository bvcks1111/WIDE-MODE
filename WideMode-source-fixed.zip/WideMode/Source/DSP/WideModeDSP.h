// WIDE MODE - DSP core.
// Pure standard C++ (no JUCE dependency) so it can be unit-tested on its own.
//
// Signal flow (per sample, zero latency):
//
//   L/R in --> M/S encode --> Mid gain / Side gain
//                                 |
//                  Stereoize: side += 0.45 * HP( allpass_chain( Mid ) )
//                                 |
//                       Side *= Width      (0 = mono, 1 = original, 2 = double side)
//                                 |
//                  Bass Mono: Side = HP_LR4(Side) @ crossover (crossfaded)
//                                 |
//                       M/S decode --> Dry/Wet mix --> Output gain
//                                 |
//                  [correlation tap]  -->  Mono Check (crossfaded)  --> out
//
// Only the SIDE signal is ever modified by Width / Stereoize / Bass Mono, so the
// mono sum (L+R)/2 is mathematically identical to the input's mono sum:
// widening can never cause phase-cancellation in a mono fold-down.
#pragma once

#include <algorithm>
#include <atomic>
#include <cmath>

namespace widemode
{
constexpr double kPi = 3.14159265358979323846;

struct Params
{
    float widthPct     = 100.0f;  // 0..200
    float stereoizePct = 0.0f;    // 0..100
    bool  bassMonoOn   = false;
    float bassFreqHz   = 120.0f;  // 60..300
    float midDb        = 0.0f;    // -24..+12
    float sideDb       = 0.0f;    // -24..+12
    float mixPct       = 100.0f;  // 0..100
    float outputDb     = 0.0f;    // -18..+18
    bool  monoCheck    = false;
};

namespace detail
{
    inline double dbToGain (double db) { return std::pow (10.0, db * 0.05); }

    /// One-pole exponential parameter smoother (click-free parameter changes).
    class Smoother
    {
    public:
        void prepare (double sampleRate, double ms)
        {
            a = 1.0 - std::exp (-1.0 / (ms * 0.001 * sampleRate));
        }
        void snap (double v) { cur = target = v; }
        void set (double t)  { target = t; }
        inline double next()
        {
            cur += a * (target - cur);
            if (std::abs (target - cur) < 1.0e-9) cur = target;
            return cur;
        }
    private:
        double cur = 0.0, target = 0.0, a = 0.01;
    };

    /// 2nd-order Butterworth high-pass, TPT state-variable form (stable under
    /// cutoff modulation). Two in series = Linkwitz-Riley 4th order (24 dB/oct).
    class HighpassSVF
    {
    public:
        void setCutoff (double fc, double sampleRate)
        {
            const double g = std::tan (kPi * std::min (fc, sampleRate * 0.45) / sampleRate);
            k  = std::sqrt (2.0);                 // 1/Q, Q = 0.7071
            a1 = 1.0 / (1.0 + g * (g + k));
            a2 = g * a1;
            a3 = g * a2;
        }
        void reset() { ic1 = ic2 = 0.0; }
        inline double process (double x)
        {
            const double v3 = x - ic2;
            const double v1 = a1 * ic1 + a2 * v3;
            const double v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2.0 * v1 - ic1;
            ic2 = 2.0 * v2 - ic2;
            return x - k * v1 - v2;
        }
    private:
        double k = 1.41421356, a1 = 0, a2 = 0, a3 = 0, ic1 = 0, ic2 = 0;
    };

    /// 2nd-order all-pass (unity magnitude, frequency-dependent phase).
    class AllpassBiquad
    {
    public:
        void set (double f, double q, double sampleRate)
        {
            const double w0 = 2.0 * kPi * std::min (f, sampleRate * 0.45) / sampleRate;
            const double alpha = std::sin (w0) / (2.0 * q);
            const double cw = std::cos (w0);
            const double a0 = 1.0 + alpha;
            b0 = (1.0 - alpha) / a0;
            b1 = (-2.0 * cw) / a0;
            b2 = (1.0 + alpha) / a0;
            a1 = b1;
            a2 = b0;
        }
        void reset() { z1 = z2 = 0.0; }
        inline double process (double x)
        {
            const double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }
    private:
        double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    };

    /// Running Pearson correlation of L/R with a ~300 ms time constant.
    class CorrelationTracker
    {
    public:
        void prepare (double sampleRate) { a = 1.0 - std::exp (-1.0 / (0.3 * sampleRate)); }
        void reset() { ll = rr = lr = 0.0; last = 1.0; }
        inline void push (double l, double r)
        {
            ll += a * (l * l - ll);
            rr += a * (r * r - rr);
            lr += a * (l * r - lr);
        }
        float get()
        {
            if (ll + rr < 1.0e-10)            // silence: hold last value
                return (float) last;
            const double den = std::sqrt (ll * rr);
            last = den < 1.0e-14 ? 0.0 : std::clamp (lr / den, -1.0, 1.0);
            return (float) last;
        }
    private:
        double a = 1e-4, ll = 0, rr = 0, lr = 0, last = 1.0;
    };

    inline void atomicMax (std::atomic<float>& a, float v) noexcept
    {
        float cur = a.load (std::memory_order_relaxed);
        while (v > cur && ! a.compare_exchange_weak (cur, v, std::memory_order_relaxed)) {}
    }
} // namespace detail

class WideModeDSP
{
public:
    static constexpr int kNumAllpass    = 5;
    static constexpr int kCoefInterval  = 32;   // crossover coefficient refresh (samples)
    // Max level of the decorrelated side signal relative to Mid at Stereoize = 100%.
    // Higher values widen more but tilt L/R tone more at frequencies where the
    // all-pass phase is near 0/180 degrees; 0.45 keeps the effect natural.
    static constexpr double kStereoizeDepth = 0.45;

    void prepare (double sampleRate)
    {
        fs = sampleRate;
        for (auto* s : { &sWidth, &sStereo, &sBass, &sMid, &sSide, &sMix, &sOut })
            s->prepare (fs, 15.0);
        sMono.prepare (fs, 8.0);
        sFreq.prepare (fs, 40.0);

        // Decorrelation network: broadly spread all-pass phase so the added side
        // signal is "a different time/phase picture of the mid", not an echo.
        static constexpr double freqs[kNumAllpass] = { 220.0, 640.0, 1750.0, 4800.0, 11000.0 };
        for (int i = 0; i < kNumAllpass; ++i)
            allpass[i].set (freqs[i], 0.6, fs);

        stereoizeHpG = 1.0 - std::exp (-2.0 * kPi * 180.0 / fs);
        corrIn.prepare (fs);
        corrOut.prepare (fs);
        reset();
        setParams (Params {}, true);
    }

    void reset()
    {
        for (auto& a : allpass) a.reset();
        stereoizeHpState = 0.0;
        hp1.reset();
        hp2.reset();
        corrIn.reset();
        corrOut.reset();
        coefCounter = 0;
        inPeakL = inPeakR = outPeakL = outPeakR = 0.0f;
        inCorr = outCorr = 1.0f;
    }

    void setParams (const Params& p, bool snap = false)
    {
        const double fcMax = fs * 0.45;
        const double w   = std::clamp ((double) p.widthPct, 0.0, 200.0) / 100.0;
        const double st  = std::clamp ((double) p.stereoizePct, 0.0, 100.0) / 100.0;
        const double fc  = std::clamp ((double) p.bassFreqHz, 20.0, fcMax);
        const double mid = dbToGain (std::clamp ((double) p.midDb,  -60.0, 24.0));
        const double sid = dbToGain (std::clamp ((double) p.sideDb, -60.0, 24.0));
        const double mix = std::clamp ((double) p.mixPct, 0.0, 100.0) / 100.0;
        const double out = dbToGain (std::clamp ((double) p.outputDb, -48.0, 24.0));
        const double bas = p.bassMonoOn ? 1.0 : 0.0;
        const double mon = p.monoCheck ? 1.0 : 0.0;

        if (snap)
        {
            sWidth.snap (w); sStereo.snap (st); sBass.snap (bas); sMid.snap (mid);
            sSide.snap (sid); sMix.snap (mix); sOut.snap (out); sMono.snap (mon);
            sFreq.snap (fc);
            setCrossover (fc);
        }
        else
        {
            sWidth.set (w); sStereo.set (st); sBass.set (bas); sMid.set (mid);
            sSide.set (sid); sMix.set (mix); sOut.set (out); sMono.set (mon);
            sFreq.set (fc);
        }
    }

    /// In-place stereo processing. left/right must be distinct buffers.
    void process (float* left, float* right, int numSamples) noexcept
    {
        float pInL = 0.f, pInR = 0.f, pOutL = 0.f, pOutR = 0.f;

        for (int i = 0; i < numSamples; ++i)
        {
            const double width = sWidth.next();
            const double st    = sStereo.next();
            const double bass  = sBass.next();
            const double midG  = sMid.next();
            const double sideG = sSide.next();
            const double mix   = sMix.next();
            const double outG  = sOut.next();
            const double mono  = sMono.next();
            const double fc    = sFreq.next();

            double inL = left[i], inR = right[i];
            if (! (std::abs (inL) < 1.0e9)) inL = 0.0;   // NaN / Inf guard
            if (! (std::abs (inR) < 1.0e9)) inR = 0.0;

            pInL = std::max (pInL, (float) std::abs (inL));
            pInR = std::max (pInR, (float) std::abs (inR));
            corrIn.push (inL, inR);

            // ---- M/S encode + independent gains
            const double m = 0.5 * (inL + inR) * midG;
            double s       = 0.5 * (inL - inR) * sideG;

            // ---- Stereoize: decorrelated, mono-safe side content derived from Mid
            double d = m;
            for (auto& ap : allpass) d = ap.process (d);
            stereoizeHpState += stereoizeHpG * (d - stereoizeHpState);   // 1-pole HP ~180 Hz
            d -= stereoizeHpState;
            s += st * kStereoizeDepth * d;

            // ---- Width
            s *= width;

            // ---- Bass mono (LR4 high-pass on the side channel, crossfaded)
            if (++coefCounter >= kCoefInterval)
            {
                coefCounter = 0;
                if (std::abs (fc - appliedFc) > 0.01) setCrossover (fc);
            }
            const double sHp = hp2.process (hp1.process (s));
            s += bass * (sHp - s);

            // ---- Decode, mix, output gain
            const double wetL = m + s, wetR = m - s;
            double oL = (inL + mix * (wetL - inL)) * outG;
            double oR = (inR + mix * (wetR - inR)) * outG;

            corrOut.push (oL, oR);                       // correlation of what is being produced

            // ---- Mono check (crossfaded fold-down)
            const double mo = 0.5 * (oL + oR);
            oL += mono * (mo - oL);
            oR += mono * (mo - oR);

            left[i]  = (float) oL;
            right[i] = (float) oR;
            pOutL = std::max (pOutL, (float) std::abs (oL));
            pOutR = std::max (pOutR, (float) std::abs (oR));
        }

        // Peaks accumulate until the UI reads them with exchange(0).
        detail::atomicMax (inPeakL, pInL);   detail::atomicMax (inPeakR, pInR);
        detail::atomicMax (outPeakL, pOutL); detail::atomicMax (outPeakR, pOutR);
        inCorr.store (corrIn.get(),  std::memory_order_relaxed);
        outCorr.store (corrOut.get(), std::memory_order_relaxed);
    }

    int getLatencySamples() const noexcept { return 0; }

    // Metering (written by the audio thread, read by the UI thread).
    std::atomic<float> inPeakL { 0.f }, inPeakR { 0.f }, outPeakL { 0.f }, outPeakR { 0.f };
    std::atomic<float> inCorr { 1.f }, outCorr { 1.f };

private:
    using Smoother = detail::Smoother;

    static double dbToGain (double db) { return detail::dbToGain (db); }

    void setCrossover (double fc)
    {
        appliedFc = fc;
        hp1.setCutoff (fc, fs);
        hp2.setCutoff (fc, fs);
    }

    double fs = 48000.0;
    Smoother sWidth, sStereo, sBass, sMid, sSide, sMix, sOut, sMono, sFreq;

    detail::AllpassBiquad allpass[kNumAllpass];
    double stereoizeHpG = 0.01, stereoizeHpState = 0.0;

    detail::HighpassSVF hp1, hp2;
    double appliedFc = 120.0;
    int coefCounter = 0;

    detail::CorrelationTracker corrIn, corrOut;
};

} // namespace widemode
