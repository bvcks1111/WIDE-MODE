// WIDE MODE - DSP unit tests (no JUCE required).
//   g++ -O2 -std=c++17 Tests/DspTests.cpp -o dsp_tests && ./dsp_tests
#include "../Source/DSP/WideModeDSP.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <random>
#include <vector>

using namespace widemode;

namespace
{
int g_failures = 0;
int g_testFailsAtStart = 0;

#define CHECK(cond, ...)                                  \
    do { if (! (cond)) { ++g_failures; std::printf ("      FAIL: "); \
         std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

void begin (const char* name) { g_testFailsAtStart = g_failures; std::printf ("[ .. ] %s\n", name); }
void end (const char* name)
{
    std::printf ("[%s] %s\n", g_failures == g_testFailsAtStart ? "PASS" : "FAIL", name);
}

struct Stereo { std::vector<float> l, r; };

Stereo noise (int n, unsigned seed, float amp = 0.5f)
{
    std::mt19937 rng (seed);
    std::uniform_real_distribution<float> dist (-amp, amp);
    Stereo s { std::vector<float> (n), std::vector<float> (n) };
    for (int i = 0; i < n; ++i) { s.l[i] = dist (rng); s.r[i] = dist (rng); }
    return s;
}

Stereo monoNoise (int n, unsigned seed, float amp = 0.5f)
{
    auto s = noise (n, seed, amp);
    s.r = s.l;
    return s;
}

Stereo sine (int n, double fs, double f, double ampL, double ampR)
{
    Stereo s { std::vector<float> (n), std::vector<float> (n) };
    for (int i = 0; i < n; ++i)
    {
        const double p = 2.0 * kPi * f * i / fs;
        s.l[i] = (float) (ampL * std::sin (p));
        s.r[i] = (float) (ampR * std::sin (p));
    }
    return s;
}

Stereo run (WideModeDSP& d, const Stereo& in, int block = 512)
{
    Stereo out = in;
    for (int pos = 0; pos < (int) in.l.size(); pos += block)
    {
        const int n = std::min (block, (int) in.l.size() - pos);
        d.process (out.l.data() + pos, out.r.data() + pos, n);
    }
    return out;
}

struct Fx : WideModeDSP
{
    Fx (double sampleRate, const Params& p) { prepare (sampleRate); setParams (p, true); }
};

double rms (const std::vector<float>& v, int from, int to)
{
    double a = 0;
    for (int i = from; i < to; ++i) a += (double) v[i] * v[i];
    return std::sqrt (a / std::max (1, to - from));
}

double toDb (double x) { return 20.0 * std::log10 (std::max (x, 1e-12)); }

double correlation (const Stereo& s, int from)
{
    double ll = 0, rr = 0, lr = 0;
    for (int i = from; i < (int) s.l.size(); ++i)
    { ll += (double) s.l[i] * s.l[i]; rr += (double) s.r[i] * s.r[i]; lr += (double) s.l[i] * s.r[i]; }
    return lr / std::sqrt (ll * rr);
}

double maxMonoSumError (const Stereo& in, const Stereo& out)
{
    double e = 0;
    for (size_t i = 0; i < in.l.size(); ++i)
        e = std::max (e, std::abs (0.5 * ((double) out.l[i] + out.r[i]) - 0.5 * ((double) in.l[i] + in.r[i])));
    return e;
}

const double kRates[] = { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 };
} // namespace

int main()
{
    // ---------------------------------------------------------------------
    begin ("1. Transparency: default settings are bit-transparent");
    for (double fs : kRates)
    {
        auto in = noise ((int) fs, 1);
        Fx d (fs, Params {});
        auto out = run (d, in);
        double e = 0;
        for (size_t i = 0; i < in.l.size(); ++i)
            e = std::max ({ e, (double) std::abs (out.l[i] - in.l[i]), (double) std::abs (out.r[i] - in.r[i]) });
        std::printf ("      fs=%6.0f  max error = %.2e (%.1f dB)\n", fs, e, toDb (e));
        CHECK (e < 1e-6, "default settings altered the signal at fs=%.0f", fs);
    }
    end ("1. Transparency: default settings are bit-transparent");

    // ---------------------------------------------------------------------
    begin ("2. Width 0% collapses to exact mono (L = R = (L+R)/2)");
    {
        Params p; p.widthPct = 0.f;
        auto in = noise (48000, 2);
        Fx d (48000, p);
        auto out = run (d, in);
        double eLR = 0, eM = 0;
        for (size_t i = 0; i < in.l.size(); ++i)
        {
            eLR = std::max (eLR, (double) std::abs (out.l[i] - out.r[i]));
            eM  = std::max (eM,  std::abs (out.l[i] - 0.5 * ((double) in.l[i] + in.r[i])));
        }
        std::printf ("      |L-R| = %.2e   |L-M| = %.2e\n", eLR, eM);
        CHECK (eLR < 1e-6 && eM < 1e-6, "width 0 is not mono");
    }
    end ("2. Width 0% collapses to exact mono (L = R = (L+R)/2)");

    // ---------------------------------------------------------------------
    begin ("3. Width 200% doubles the side signal, mid untouched");
    {
        Params p; p.widthPct = 200.f;
        auto in = noise (48000, 3, 0.3f);
        Fx d (48000, p);
        auto out = run (d, in);
        double eS = 0, eM = 0;
        for (size_t i = 0; i < in.l.size(); ++i)
        {
            const double sIn = 0.5 * ((double) in.l[i] - in.r[i]), mIn = 0.5 * ((double) in.l[i] + in.r[i]);
            const double sOut = 0.5 * ((double) out.l[i] - out.r[i]), mOut = 0.5 * ((double) out.l[i] + out.r[i]);
            eS = std::max (eS, std::abs (sOut - 2.0 * sIn));
            eM = std::max (eM, std::abs (mOut - mIn));
        }
        std::printf ("      side error = %.2e   mid error = %.2e\n", eS, eM);
        CHECK (eS < 1e-6 && eM < 1e-6, "width 200 scaling wrong");
    }
    end ("3. Width 200% doubles the side signal, mid untouched");

    // ---------------------------------------------------------------------
    begin ("4. Mono compatibility: mono sum is identical to input at ANY widening setting");
    for (double fs : kRates)
    {
        Params p; p.widthPct = 200.f; p.stereoizePct = 100.f; p.bassMonoOn = true;
        p.bassFreqHz = 150.f; p.sideDb = 6.f;
        auto in = noise ((int) fs, 4, 0.4f);
        Fx d (fs, p);
        auto out = run (d, in);
        const double e = maxMonoSumError (in, out);
        std::printf ("      fs=%6.0f  worst-case mono-sum deviation = %.2e (%.0f dB)\n", fs, e, toDb (e));
        CHECK (e < 1e-6, "mono sum changed at fs=%.0f (phase cancellation risk)", fs);
    }
    end ("4. Mono compatibility: mono sum is identical to input at ANY widening setting");

    // ---------------------------------------------------------------------
    begin ("5. Bass Mono: 4th-order Linkwitz-Riley high-pass on the side channel");
    {
        const double fs = 48000.0, fc = 150.0;
        Params p; p.bassMonoOn = true; p.bassFreqHz = (float) fc;
        // LR4 high-pass magnitude: w^4 / (1 + w^4), w = f / fc  (-6.02 dB at fc)
        for (double f : { 40.0, 75.0, 150.0, 300.0, 600.0, 5000.0 })
        {
            auto in = sine ((int) fs * 2, fs, f, 0.5, -0.5);        // pure side signal
            Fx d (fs, p);
            auto out = run (d, in);
            const int a = (int) fs, b = (int) fs * 2;
            const double g = toDb (rms (out.l, a, b) / rms (in.l, a, b));
            const double w4 = std::pow (f / fc, 4.0);
            const double ideal = toDb (w4 / (1.0 + w4));
            std::printf ("      side @ %6.0f Hz -> %7.2f dB   (ideal LR4: %7.2f dB)\n", f, g, ideal);
            CHECK (std::abs (g - ideal) < 0.25, "off by %.2f dB at %.0f Hz", g - ideal, f);
        }
        // A centered (mono) bass note must be completely untouched.
        auto in = sine ((int) fs, fs, 60.0, 0.5, 0.5);
        Fx d (fs, p);
        auto out = run (d, in);
        double e = 0;
        for (size_t i = 0; i < in.l.size(); ++i) e = std::max (e, (double) std::abs (out.l[i] - in.l[i]));
        std::printf ("      centered 60 Hz tone error = %.2e\n", e);
        CHECK (e < 1e-6, "mono bass was altered");
    }
    end ("5. Bass Mono: 4th-order Linkwitz-Riley high-pass on the side channel");

    // ---------------------------------------------------------------------
    begin ("6. Stereoize: decorrelates a mono source, bounded loudness change");
    for (double fs : { 44100.0, 48000.0, 96000.0 })
    {
        Params p; p.stereoizePct = 100.f;
        auto in = monoNoise ((int) fs * 2, 6, 0.3f);
        Fx d (fs, p);
        auto out = run (d, in);
        const int a = (int) fs / 2;
        const double c = correlation (out, a);
        const int e = (int) out.l.size();
        const double pOut = 0.5 * (rms (out.l, a, e) * rms (out.l, a, e) + rms (out.r, a, e) * rms (out.r, a, e));
        const double dB = 10.0 * std::log10 (pOut / (rms (in.l, a, e) * rms (in.l, a, e)));
        const double tilt = toDb (rms (out.l, a, e) / rms (out.r, a, e));
        std::printf ("      fs=%6.0f  output L/R correlation = %.3f   avg level change = %+.2f dB   L/R tilt = %+.2f dB\n", fs, c, dB, tilt);
        CHECK (c < 0.8 && c > 0.0, "unexpected correlation %.3f", c);
        CHECK (dB < 1.0 && dB > 0.0, "level change %.2f dB too large", dB);
        CHECK (std::abs (tilt) < 1.0, "L/R tilt %.2f dB too large", tilt);
    }
    end ("6. Stereoize: decorrelates a mono source, bounded loudness change");

    // ---------------------------------------------------------------------
    begin ("7. Stereoize all-pass network is magnitude-flat (no coloration)");
    {
        // Mid-only sine; at stereoize 100% the side contains the all-pass'd mid.
        // Mid component of the output must be unchanged at every frequency.
        const double fs = 48000.0;
        Params p; p.stereoizePct = 100.f;
        for (double f : { 100.0, 400.0, 1000.0, 3000.0, 8000.0, 15000.0 })
        {
            auto in = sine ((int) fs, fs, f, 0.5, 0.5);
            Fx d (fs, p);
            auto out = run (d, in);
            double e = 0;
            for (int i = (int) fs / 2; i < (int) fs; ++i)
                e = std::max (e, std::abs (0.5 * ((double) out.l[i] + out.r[i]) - in.l[i]));
            CHECK (e < 1e-6, "mid changed by %.2e at %.0f Hz", e, f);
        }
    }
    end ("7. Stereoize all-pass network is magnitude-flat (no coloration)");

    // ---------------------------------------------------------------------
    begin ("8. Click-free: abrupt parameter changes are smoothed");
    {
        const double fs = 48000.0;
        auto in = sine ((int) fs * 2, fs, 1000.0, 0.5, 0.2);
        Params a;                                    // start: neutral
        Params b; b.widthPct = 200.f; b.stereoizePct = 100.f; b.bassMonoOn = true;
        b.bassFreqHz = 300.f; b.midDb = 6.f; b.sideDb = -12.f; b.mixPct = 20.f; b.outputDb = -6.f; b.monoCheck = true;
        Fx d (fs, a);
        Stereo out = in;
        const int jump = (int) fs;
        d.process (out.l.data(), out.r.data(), jump);
        d.setParams (b);
        d.process (out.l.data() + jump, out.r.data() + jump, (int) fs);
        double worst = 0;
        for (int i = jump - 20; i < jump + 4000; ++i)
        {
            worst = std::max (worst, (double) std::abs (out.l[i + 1] - out.l[i]));
            worst = std::max (worst, (double) std::abs (out.r[i + 1] - out.r[i]));
        }
        // Steady 1 kHz at ~0.5 amplitude moves at most ~0.07/sample.
        std::printf ("      largest sample-to-sample step across the jump = %.4f\n", worst);
        CHECK (worst < 0.15, "audible discontinuity (step %.4f)", worst);
    }
    end ("8. Click-free: abrupt parameter changes are smoothed");

    // ---------------------------------------------------------------------
    begin ("9. Mono Check: output is the exact fold-down of the processed signal");
    {
        Params p; p.widthPct = 170.f; p.stereoizePct = 50.f; p.bassMonoOn = true;
        auto in = noise (48000, 9, 0.4f);
        Fx d1 (48000, p);
        p.monoCheck = true;
        Fx d2 (48000, p);
        auto ref = run (d1, in);
        auto mon = run (d2, in);
        double e = 0, eLR = 0;
        for (size_t i = 0; i < in.l.size(); ++i)
        {
            e   = std::max (e,   std::abs (mon.l[i] - 0.5 * ((double) ref.l[i] + ref.r[i])));
            eLR = std::max (eLR, (double) std::abs (mon.l[i] - mon.r[i]));
        }
        std::printf ("      fold-down error = %.2e   |L-R| = %.2e\n", e, eLR);
        CHECK (e < 1e-6 && eLR < 1e-6, "mono check mismatch");
    }
    end ("9. Mono Check: output is the exact fold-down of the processed signal");

    // ---------------------------------------------------------------------
    begin ("10. Correlation meter reads +1 (mono), -1 (anti-phase), ~0 (uncorrelated)");
    {
        const double fs = 48000.0;
        { Fx d (fs, Params {}); auto in = monoNoise ((int) fs * 2, 10); run (d, in);
          std::printf ("      mono        -> %+.3f\n", d.inCorr.load()); CHECK (d.inCorr.load() > 0.99f, "mono"); }
        { Fx d (fs, Params {}); auto in = monoNoise ((int) fs * 2, 10);
          for (auto& x : in.r) x = -x;
          run (d, in);
          std::printf ("      anti-phase  -> %+.3f\n", d.inCorr.load()); CHECK (d.inCorr.load() < -0.99f, "anti"); }
        { Fx d (fs, Params {}); auto in = noise ((int) fs * 4, 11); run (d, in);
          std::printf ("      independent -> %+.3f\n", d.inCorr.load()); CHECK (std::abs (d.inCorr.load()) < 0.15f, "indep"); }
        { Params p; p.widthPct = 0.f; Fx d (fs, p); auto in = noise ((int) fs * 2, 12); run (d, in);
          std::printf ("      width 0 out -> %+.3f\n", d.outCorr.load()); CHECK (d.outCorr.load() > 0.99f, "out corr at width 0"); }
    }
    end ("10. Correlation meter reads +1 (mono), -1 (anti-phase), ~0 (uncorrelated)");

    // ---------------------------------------------------------------------
    begin ("11. Peak meters");
    {
        const double fs = 48000.0;
        Fx d (fs, Params {});
        auto in = sine ((int) fs / 2, fs, 997.0, 0.5, 0.25);
        run (d, in);
        const float pl = d.inPeakL.exchange (0.f), pr = d.inPeakR.exchange (0.f);
        std::printf ("      in peaks L=%.3f R=%.3f   after reset: %.3f\n", pl, pr, d.inPeakL.load());
        CHECK (std::abs (pl - 0.5f) < 0.01f && std::abs (pr - 0.25f) < 0.01f && d.inPeakL.load() == 0.f, "peak meter wrong");
    }
    end ("11. Peak meters");

    // ---------------------------------------------------------------------
    begin ("12. Block-size independence (bit-exact for 1, 7, 64, 480, 4096)");
    {
        Params p; p.widthPct = 150.f; p.stereoizePct = 40.f; p.bassMonoOn = true; p.bassFreqHz = 180.f;
        auto in = noise (48000, 13);
        Fx d0 (48000, p);
        auto ref = run (d0, in, 48000);
        for (int blk : { 1, 7, 64, 480, 4096 })
        {
            Fx d (48000, p);
            auto out = run (d, in, blk);
            double e = 0;
            for (size_t i = 0; i < in.l.size(); ++i)
                e = std::max ({ e, (double) std::abs (out.l[i] - ref.l[i]), (double) std::abs (out.r[i] - ref.r[i]) });
            CHECK (e == 0.0, "block %d differs by %.2e", blk, e);
        }
    }
    end ("12. Block-size independence (bit-exact for 1, 7, 64, 480, 4096)");

    // ---------------------------------------------------------------------
    begin ("13. Robustness: extreme settings, full-scale input, NaN/Inf injection");
    {
        Params p; p.widthPct = 200.f; p.stereoizePct = 100.f; p.bassMonoOn = true; p.bassFreqHz = 60.f;
        p.midDb = 12.f; p.sideDb = 12.f; p.outputDb = 18.f;
        auto in = noise (96000, 14, 1.0f);
        in.l[1000] = std::numeric_limits<float>::quiet_NaN();
        in.r[2000] = std::numeric_limits<float>::infinity();
        Fx d (48000, p);
        auto out = run (d, in);
        bool finite = true;
        for (size_t i = 0; i < in.l.size(); ++i)
            finite = finite && std::isfinite (out.l[i]) && std::isfinite (out.r[i]);
        CHECK (finite, "non-finite output sample");
        // Sweep the crossover wildly while processing; must stay finite and bounded.
        Fx d2 (48000, Params {});
        Stereo x = noise (48000 * 4, 15, 1.0f);
        for (int pos = 0, k = 0; pos < (int) x.l.size(); pos += 256, ++k)
        {
            Params q; q.bassMonoOn = true; q.widthPct = 200.f; q.bassFreqHz = (k % 2) ? 60.f : 300.f;
            d2.setParams (q);
            d2.process (x.l.data() + pos, x.r.data() + pos, 256);
        }
        double peak = 0;
        for (size_t i = 0; i < x.l.size(); ++i) peak = std::max ({ peak, (double) std::abs (x.l[i]), (double) std::abs (x.r[i]) });
        std::printf ("      peak under abusive crossover modulation = %.2f\n", peak);
        CHECK (std::isfinite (peak) && peak < 8.0, "unstable under modulation");
    }
    end ("13. Robustness: extreme settings, full-scale input, NaN/Inf injection");

    // ---------------------------------------------------------------------
    begin ("14. CPU cost");
    {
        const double fs = 48000.0;
        const int secs = 60;
        Params p; p.widthPct = 150.f; p.stereoizePct = 50.f; p.bassMonoOn = true;
        auto in = noise ((int) fs * secs, 16);
        Fx d (fs, p);
        const auto t0 = std::chrono::steady_clock::now();
        auto out = run (d, in, 256);
        const auto t1 = std::chrono::steady_clock::now();
        const double sec = std::chrono::duration<double> (t1 - t0).count();
        std::printf ("      %d s of stereo audio @48k processed in %.3f s  ->  %.2f%% of one core (%.0fx realtime)\n",
                     secs, sec, 100.0 * sec / secs, secs / sec);
        #ifdef NDEBUG
        CHECK (sec / secs < 0.02, "too slow: %.1f%% CPU", 100.0 * sec / secs);
#else
        CHECK (sec / secs < 0.50, "too slow even for a debug build: %.1f%% CPU", 100.0 * sec / secs);
#endif
    }
    end ("14. CPU cost");

    std::printf ("\n%s (%d failed check%s)\n", g_failures == 0 ? "ALL TESTS PASSED" : "TESTS FAILED",
                 g_failures, g_failures == 1 ? "" : "s");
    return g_failures == 0 ? 0 : 1;
}
